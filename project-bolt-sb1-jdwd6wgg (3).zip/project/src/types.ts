export interface RoommatePost {
  id: string;
  title: string;
  description: string;
  rent: number;
  location: string;
  preferences: string[];
  amenities: string[];
  postedBy: string;
  postedDate: string;
  imageUrl: string;
  moveInDate: string;
  roomType: 'private' | 'shared';
  duration: string;
  deposit: number;
  billsIncluded: boolean;
}

export interface FilterOptions {
  minRent: number;
  maxRent: number;
  location: string;
  roomType?: 'private' | 'shared';
  moveInDate?: string;
  amenities: string[];
}

export type SortOption = 'newest' | 'price-low' | 'price-high';