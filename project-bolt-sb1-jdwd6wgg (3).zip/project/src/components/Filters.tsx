import React from 'react';
import type { FilterOptions } from '../types';

interface FiltersProps {
  filters: FilterOptions;
  onFilterChange: (filters: FilterOptions) => void;
}

export default function Filters({ filters, onFilterChange }: FiltersProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm space-y-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Filters</h3>
      
      {/* Rent Range */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">Price Range</label>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <input
              type="number"
              value={filters.minRent}
              onChange={(e) => onFilterChange({
                ...filters,
                minRent: parseInt(e.target.value) || 0
              })}
              placeholder="Min"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
          <div>
            <input
              type="number"
              value={filters.maxRent}
              onChange={(e) => onFilterChange({
                ...filters,
                maxRent: parseInt(e.target.value) || 0
              })}
              placeholder="Max"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Location */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">Location</label>
        <input
          type="text"
          value={filters.location}
          onChange={(e) => onFilterChange({
            ...filters,
            location: e.target.value
          })}
          placeholder="Enter location"
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      {/* Room Type */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">Room Type</label>
        <select
          value={filters.roomType || ''}
          onChange={(e) => onFilterChange({
            ...filters,
            roomType: e.target.value as 'private' | 'shared' | undefined
          })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
        >
          <option value="">Any</option>
          <option value="private">Private Room</option>
          <option value="shared">Shared Room</option>
        </select>
      </div>

      {/* Move-in Date */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">Move-in Date</label>
        <input
          type="date"
          value={filters.moveInDate || ''}
          onChange={(e) => onFilterChange({
            ...filters,
            moveInDate: e.target.value
          })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      {/* Amenities */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">Amenities</label>
        <div className="space-y-2">
          {['WiFi', 'Furnished', 'AC', 'Parking', 'Gym', 'Pets Allowed'].map((amenity) => (
            <label key={amenity} className="flex items-center">
              <input
                type="checkbox"
                checked={filters.amenities.includes(amenity)}
                onChange={(e) => {
                  const newAmenities = e.target.checked
                    ? [...filters.amenities, amenity]
                    : filters.amenities.filter(a => a !== amenity);
                  onFilterChange({
                    ...filters,
                    amenities: newAmenities
                  });
                }}
                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
              />
              <span className="ml-2 text-sm text-gray-600">{amenity}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Reset Filters */}
      <button
        onClick={() => onFilterChange({
          minRent: 0,
          maxRent: 5000,
          location: '',
          amenities: [],
          roomType: undefined,
          moveInDate: undefined
        })}
        className="w-full px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
      >
        Reset Filters
      </button>
    </div>
  );
}