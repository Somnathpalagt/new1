import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import ListingCard from './components/ListingCard';
import Filters from './components/Filters';
import Dashboard from './components/Dashboard';
import { supabase } from './lib/supabase';
import type { RoommatePost, FilterOptions, SortOption } from './types';
import { Toaster } from 'react-hot-toast';

function App() {
  const [showDashboard, setShowDashboard] = useState(false);
  const [listings, setListings] = useState<RoommatePost[]>([]);
  const [filters, setFilters] = useState<FilterOptions>({
    minRent: 0,
    maxRent: 5000,
    location: '',
    amenities: []
  });
  const [sortBy, setSortBy] = useState<SortOption>('newest');

  useEffect(() => {
    fetchListings();
    
    // Check if we should show dashboard (URL contains /dashboard)
    setShowDashboard(window.location.pathname.includes('dashboard'));

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session && showDashboard) {
        window.location.href = '/';
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchListings = async () => {
    try {
      const { data, error } = await supabase
        .from('listings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setListings(data || []);
    } catch (error) {
      console.error('Error fetching listings:', error);
    }
  };

  const filteredListings = listings.filter((listing) => {
    const matchesRent = listing.rent >= filters.minRent && 
      (filters.maxRent === 0 || listing.rent <= filters.maxRent);
    const matchesLocation = !filters.location || 
      listing.location.toLowerCase().includes(filters.location.toLowerCase());
    const matchesRoomType = !filters.roomType || listing.roomType === filters.roomType;
    const matchesMoveInDate = !filters.moveInDate || listing.moveInDate >= filters.moveInDate;
    const matchesAmenities = filters.amenities.length === 0 || 
      filters.amenities.every(amenity => listing.amenities.includes(amenity));

    return matchesRent && matchesLocation && matchesRoomType && 
           matchesMoveInDate && matchesAmenities;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.rent - b.rent;
      case 'price-high':
        return b.rent - a.rent;
      case 'newest':
      default:
        return new Date(b.postedDate).getTime() - new Date(a.postedDate).getTime();
    }
  });

  if (showDashboard) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <Dashboard />
        <Toaster position="top-right" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            Available Listings ({filteredListings.length})
          </h2>
          <div className="flex items-center space-x-4">
            <label className="text-sm text-gray-600">Sort by:</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="newest">Newest First</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-8">
          <div className="col-span-1">
            <div className="sticky top-8">
              <Filters filters={filters} onFilterChange={setFilters} />
            </div>
          </div>
          <div className="col-span-3">
            {filteredListings.length === 0 ? (
              <div className="bg-white rounded-lg shadow-sm p-8 text-center">
                <h3 className="text-lg font-medium text-gray-900 mb-2">No listings found</h3>
                <p className="text-gray-600">Try adjusting your filters to see more results</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredListings.map((listing) => (
                  <ListingCard key={listing.id} post={listing} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      <Toaster position="top-right" />
    </div>
  );
}

export default App;