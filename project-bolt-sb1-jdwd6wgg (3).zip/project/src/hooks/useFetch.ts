import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

interface FetchState<T> {
  data: T | null;
  loading: boolean;
  error: Error | null;
}

export function useFetch<T>(
  table: string,
  query?: {
    column?: string;
    value?: any;
    orderBy?: string;
    ascending?: boolean;
  }
) {
  const [state, setState] = useState<FetchState<T>>({
    data: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        let queryBuilder = supabase
          .from(table)
          .select('*');

        if (query?.column && query?.value !== undefined) {
          queryBuilder = queryBuilder.eq(query.column, query.value);
        }

        if (query?.orderBy) {
          queryBuilder = queryBuilder.order(query.orderBy, {
            ascending: query.ascending ?? false,
          });
        }

        const { data, error } = await queryBuilder;

        if (error) throw error;

        setState({
          data: data as T,
          loading: false,
          error: null,
        });
      } catch (error) {
        setState({
          data: null,
          loading: false,
          error: error as Error,
        });
        toast.error('Error fetching data');
      }
    };

    fetchData();
  }, [table, query?.column, query?.value, query?.orderBy, query?.ascending]);

  return state;
}